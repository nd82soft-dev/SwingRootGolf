module.exports=[2034,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GitHub_AISwing_web__next-internal_server_app_drills_page_actions_3031e071.js.map