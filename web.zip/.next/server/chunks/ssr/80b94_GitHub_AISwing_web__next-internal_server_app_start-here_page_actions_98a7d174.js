module.exports=[51047,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GitHub_AISwing_web__next-internal_server_app_start-here_page_actions_98a7d174.js.map