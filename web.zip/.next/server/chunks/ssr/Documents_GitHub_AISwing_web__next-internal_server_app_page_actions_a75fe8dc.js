module.exports=[30066,(a,b,c)=>{}];

//# sourceMappingURL=Documents_GitHub_AISwing_web__next-internal_server_app_page_actions_a75fe8dc.js.map