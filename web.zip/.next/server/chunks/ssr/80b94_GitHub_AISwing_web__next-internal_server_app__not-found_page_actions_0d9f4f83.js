module.exports=[82594,(a,b,c)=>{}];

//# sourceMappingURL=80b94_GitHub_AISwing_web__next-internal_server_app__not-found_page_actions_0d9f4f83.js.map