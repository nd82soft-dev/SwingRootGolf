module.exports=[80513,(a,b,c)=>{}];

//# sourceMappingURL=7889e_AISwing_web__next-internal_server_app_drills_%5Bslug%5D_page_actions_c6eaa6dd.js.map