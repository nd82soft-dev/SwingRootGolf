module.exports=[27272,(a,b,c)=>{}];

//# sourceMappingURL=7889e_AISwing_web__next-internal_server_app__global-error_page_actions_2224016b.js.map