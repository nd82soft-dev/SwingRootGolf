module.exports=[62980,(e,o,d)=>{}];

//# sourceMappingURL=80b94_GitHub_AISwing_web__next-internal_server_app_favicon_ico_route_actions_0534636c.js.map