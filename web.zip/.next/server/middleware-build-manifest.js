globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4ce83b6b1e213edd.js",
    "static/chunks/7b625af60c7aaa47.js",
    "static/chunks/96fd292ba8e417a0.js",
    "static/chunks/551a21b167ee1964.js",
    "static/chunks/turbopack-f4509064c33dd3ae.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];