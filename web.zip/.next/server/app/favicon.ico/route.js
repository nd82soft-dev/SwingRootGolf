var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__7ddbd4eb._.js")
R.c("server/chunks/80b94_GitHub_AISwing_web__next-internal_server_app_favicon_ico_route_actions_0534636c.js")
R.m(95194)
module.exports=R.m(95194).exports
